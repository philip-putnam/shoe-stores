-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- Generation Time: Mar 03, 2017 at 11:32 PM
-- Server version: 5.5.42
-- PHP Version: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shoes_test`
--
CREATE DATABASE IF NOT EXISTS `shoes_test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `shoes_test`;

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=273 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=254 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `stores_brands`
--

CREATE TABLE `stores_brands` (
  `id` bigint(20) unsigned NOT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stores_brands`
--

INSERT INTO `stores_brands` (`id`, `brand_id`, `store_id`) VALUES
(1, 77, 50),
(2, 78, 50),
(3, 80, 51),
(4, 81, 51),
(5, 79, 51),
(6, 90, 61),
(7, 91, 61),
(8, 93, 62),
(9, 94, 62),
(10, 92, 62),
(11, 103, 72),
(12, 104, 72),
(13, 106, 73),
(14, 107, 73),
(15, 105, 73),
(16, 115, 74),
(17, 115, 75),
(18, 116, 76),
(19, 116, 77),
(20, 116, 78),
(21, 118, 88),
(22, 119, 88),
(23, 121, 89),
(24, 122, 89),
(25, 120, 89),
(26, 130, 90),
(27, 130, 91),
(28, 131, 92),
(29, 131, 93),
(30, 131, 94),
(31, 133, 104),
(32, 134, 104),
(33, 136, 105),
(34, 137, 105),
(35, 135, 105),
(36, 145, 106),
(37, 145, 107),
(38, 148, 120),
(39, 149, 120),
(40, 151, 121),
(41, 152, 121),
(42, 150, 121),
(43, 160, 122),
(44, 160, 123),
(45, 161, 124),
(46, 161, 125),
(47, 161, 126),
(48, 163, 136),
(49, 164, 136),
(50, 166, 137),
(51, 167, 137),
(52, 165, 137),
(53, 175, 138),
(54, 175, 139),
(55, 176, 140),
(56, 176, 141),
(57, 176, 142),
(58, 178, 152),
(59, 179, 152),
(60, 181, 153),
(61, 182, 153),
(62, 180, 153),
(63, 190, 154),
(64, 190, 155),
(65, 191, 156),
(66, 191, 157),
(67, 191, 158),
(68, 193, 168),
(69, 194, 168),
(70, 196, 169),
(71, 197, 169),
(72, 195, 169),
(73, 205, 170),
(74, 205, 171),
(75, 206, 172),
(76, 206, 173),
(77, 206, 174),
(78, 208, 184),
(79, 209, 184),
(80, 211, 185),
(81, 212, 185),
(82, 210, 185),
(83, 220, 186),
(84, 220, 187),
(85, 221, 188),
(86, 221, 189),
(87, 221, 190),
(88, 223, 201),
(89, 224, 201),
(90, 226, 202),
(91, 227, 202),
(92, 225, 202),
(93, 235, 203),
(94, 235, 204),
(95, 236, 205),
(96, 236, 206),
(97, 236, 207),
(98, 238, 218),
(99, 239, 218),
(100, 241, 219),
(101, 242, 219),
(102, 240, 219),
(103, 250, 220),
(104, 250, 221),
(105, 251, 222),
(106, 251, 223),
(107, 251, 224),
(108, 253, 235),
(109, 254, 235),
(110, 256, 236),
(111, 257, 236),
(112, 255, 236),
(113, 265, 237),
(114, 265, 238),
(115, 266, 239),
(116, 266, 240),
(117, 266, 241),
(118, 268, 252),
(119, 269, 252),
(120, 271, 253),
(121, 272, 253),
(122, 270, 253);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stores_brands`
--
ALTER TABLE `stores_brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=273;
--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=254;
--
-- AUTO_INCREMENT for table `stores_brands`
--
ALTER TABLE `stores_brands`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=123;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
